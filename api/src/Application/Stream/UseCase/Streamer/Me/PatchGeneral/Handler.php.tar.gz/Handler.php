<?php

declare(strict_types=1);

namespace App\Application\Stream\UseCase\Streamer\Me\PatchGeneral;

use App\Application\Common\UseCase\HandlerInterface;
use App\Domain\Common\Service\EntityManagerInterface;
use App\Domain\Stream\StreamerRepositoryInterface;

/**
 * @author Alexandru Sterpu <alexander.sterpu@gmail.com>
 */
readonly class Handler implements HandlerInterface
{
    public function __construct(
        private EntityManagerInterface $em,
        private StreamerRepositoryInterface $streamerRepo
    ) {}

    public function __invoke(Input $input)
    {
        $streamer = $this->streamerRepo->findOrFail($input->getStreamerId());

        if ($input->getNickname() !== null) {
            $streamer->setNickname($input->getNickname());
        }

        if ($input->getBannedCountries() !== null) {
            $streamer->setBannedCountries($input->getBannedCountries());
        }

        if ($input->getStreamingPlatforms() !== null) {
            $streamer->setStreamingPlatforms($input->getStreamingPlatforms());
        }

        if ($input->getLanguages() !== null) {
            $streamer->setLanguages($input->getLanguages());
        }

        if ($input->getCategories() !== null) {
            $streamer->setCategories($input->getCategories());
        }

        if ($input->getTags() !== null) {
            $streamer->setTags($input->getTags());
        }

        if ($input->getAboutMe() !== null) {
            $streamer->setAboutMe($input->getAboutMe());
        }

        if ($input->getTurnsMeOn() !== null) {
            $streamer->setTurnsMeOn($input->getTurnsMeOn());
        }

        if ($input->getTurnsMeOut() !== null) {
            $streamer->setTurnsMeOut($input->getTurnsMeOut());
        }

        $this->em->flush();
    }
}
