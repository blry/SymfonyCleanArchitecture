<?php

declare(strict_types=1);

namespace App\Infrastructure\Controller\Stream\V1\Streamers\Me\PatchGeneral;

use App\Domain\Stream\ValueObject\CountryEnum;
use App\Domain\Stream\ValueObject\LanguageEnum;
use App\Domain\Stream\ValueObject\StreamerCategoryEnum;
use App\Domain\Stream\ValueObject\StreamerTagEnum;
use Symfony\Component\Validator\Constraints as Assert;
use OpenApi\Attributes as OA;

/**
 * @author Alexandru Sterpu <alexander.sterpu@gmail.com>
 */
class PatchGeneralBody
{
    /**
     * Desirable nickname in streaming services
     */
     #[OA\Property(type: 'string', maxLength: 20, example: 'supernickname')]
     #[Assert\Type('string')]
    public $nickname;

    #[OA\Property(type: 'array', items: new OA\Items(type: 'string', enum: CountryEnum::CASES), nullable: true)]
    #[Assert\Choice(CountryEnum::CASES, multiple: true)]
    #[Assert\Unique]
    public $bannedCountries;

    #[OA\Property(type: 'array', items: new OA\Items(type: 'string'), nullable: true)]
    #[Assert\All([
        new Assert\NotBlank,
        new Assert\Type('string')
    ])]
    #[Assert\Unique]
    public $streamingPlatforms;

    #[OA\Property(type: 'array', items: new OA\Items(type: 'string', enum: LanguageEnum::CASES), nullable: true)]
    #[Assert\Choice(LanguageEnum::CASES, multiple: true)]
    #[Assert\Unique]
    public $languages;

    #[OA\Property(type: 'array', items: new OA\Items(type: 'string', enum: StreamerCategoryEnum::CASES), nullable: true)]
    #[Assert\Choice(StreamerCategoryEnum::CASES, multiple: true)]
    #[Assert\Unique]
    public $categories;

    #[OA\Property(type: 'array', items: new OA\Items(type: 'string', enum: StreamerTagEnum::CASES), nullable: true)]
    #[Assert\Choice(StreamerTagEnum::CASES, multiple: true)]
    #[Assert\Unique]
    public $tags;

    #[OA\Property(type: 'string', maxLength: 75, nullable: true)]
    #[Assert\Type('string')]
    public $aboutMe;

    #[OA\Property(type: 'string', nullable: true)]
    #[Assert\Type('string')]
    public $turnsMeOn;

    #[OA\Property(type: 'string', nullable: true)]
    #[Assert\Type('string')]
    public $turnsMeOut;
}
